###Import PyQt, functions and UI windows

from PyQt4.QtCore import *
from PyQt4.QtGui import *

import sys
import functions
import mainWindow
import addOrDeleteWindow
import statisticsWindow

class MainWindow(QWidget, mainWindow.Ui_Dialog):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        #CONNECT clicking of pushbuttons to triggering of functions inside the class
        self.connect(self.load, SIGNAL("clicked()"), self.loadItems)
        self.connect(self.save, SIGNAL("clicked()"), self.saveItems)
        self.connect(self.showExpired, SIGNAL("clicked()"), self.showExpiredItems)
        self.connect(self.showExpiring, SIGNAL("clicked()"), self.showExpiringItems)
        self.connect(self.showAll, SIGNAL("clicked()"), self.showAllItems)
        self.connect(self.addOrDelete, SIGNAL("clicked()"), self.runAddOrDelete)
        self.connect(self.showStats, SIGNAL("clicked()"), self.showStatistics)
        self.connect(self.showFromTo, SIGNAL("clicked()"), self.showFromToItems)
        self.connect(self.dateSort, SIGNAL("clicked()"), self.sortDateItems)
        self.connect(self.typeSort, SIGNAL("clicked()"), self.sortTypeItems)
        self.connect(self.weightSort, SIGNAL("clicked()"), self.sortWeightItems)

    def loadItems(self):

        text = self.loadEdit.text() #Read text from loadEdit
        self.tableWidget.setRowCount(0) #Reset table

        ###LOGIC
        try:
            functions.loadObjects(text) #Adds objects to BST
            self.actionConfirmLabel.setText("The items were loaded")
        except:
            self.actionConfirmLabel.setText("The file you have specified could not be loaded")

        ###FRONTEND
        self.showAllItems()

    def saveItems(self):

        text = self.saveEdit.text()  #Read text from saveEdit
        dates, expiryperiods, types, positions, weights = functions.returnFromTo(000101, 990101) #Return all elements in the BST
        ###LOGIC
        try:
            functions.saveObjects(text, dates[0], dates[-1]) #Exports all objects to .txt file with filename of saveEdit
            self.actionConfirmLabel.setText("The items were saved to " + str(text))
        except:
            self.actionConfirmLabel.setText("There was an error saving the foods. Please specified a valid file name.")

    def showAllItems(self):

        self.tableWidget.setRowCount(0) #Reset table

        dates, expiryperiods, types, positions, weights = functions.returnFromTo(000101, 990101) #Return all elements in the BST

        allitems = []

        for i in range(len(dates)): #Make a nested list to write to QTableWidget
            allitems.append([dates[i],expiryperiods[i], types[i], positions[i], weights[i]])
            allitems[i][0] = str(allitems[i][0])
            allitems[i][0] = allitems[i][0][4:6] + "/" + allitems[i][0][2:4] + "/" + allitems[i][0][0:2] #Reformat YYMMDD date to DD/MM/YY

        self.tableWidget.setRowCount(len(allitems)) #Format table
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date', 'Expiry Period', 'Type', 'Position', 'Weight'])

        for i, row in enumerate(allitems): #Write to QTableWidget
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

        self.tableConfirmLabel.setText("Showing all items")

        self.showItemsOnMap() #Show items on map


    def showExpiredItems(self):

        today = self.expiredEdit.text()  # Read text from expiredEdit
        self.tableWidget.setRowCount(0)  # Reset table

        expired = []

        try:
            expired = functions.showExpired(today) #
        except:
            self.actionConfirmLabel.setText("An error occured. Please enter a valid date in DD/MM/YY format")

        self.tableWidget.setRowCount(len(expired))
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date','Expiry Period', 'Position', 'Type', 'Weight'])

        for i, row in enumerate(expired):
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

        self.tableConfirmLabel.setText("These items are expired")

        self.showItemsOnMap()

    def showExpiringItems(self):

        today = self.expiredEdit.text()  #Read text from expiredEdit
        self.tableWidget.setRowCount(0)  #Reset table

        expiring = []

        try:
            expiring = functions.showExpiring(today) #Get expiring food
        except:
            self.actionConfirmLabel.setText("An error occured. Please enter a valid date in DD/MM/YY format")

        self.tableWidget.setRowCount(len(expiring)) #Format table
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date','Expiry Period', 'Position', 'Type', 'Weight'])

        for i, row in enumerate(expiring): #Write to table
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

        self.tableConfirmLabel.setText("These items are expiring today") #Set confirmation label

        self.showItemsOnMap() #Show items on map

    def runAddOrDelete(self): #Opens the Add or Delete item subwindow

        self.addOrDeleteWindowObject = addOrDeleteWindow(self)
        self.addOrDeleteWindowObject.setFocus()
        self.addOrDeleteWindowObject.show()

    def showItemsOnMap(self):

        positions = []
        for row in range(self.tableWidget.rowCount()): #Reads positions from QTableWidget
            try:
                position = str(self.tableWidget.item(row, 3).text()) #Reads positions
                positions.append(position)
            except:
                pass

        ###LOGIC
        functions.plotItems(positions)

        image = QPixmap('Map.png') #Image imported as QPixmap
        scaledimage = image.scaled(self.mapShow.size(), Qt.KeepAspectRatio) #Image scaled to size
        self.mapShow.setPixmap(scaledimage)

    def showFromToItems(self):

        self.tableWidget.setRowCount(0)  # Reset table

        fromdateString = str(self.fromEdit.text()) #Original string retained as used in the confirmation Label
        fromdate = int(fromdateString[6:8] + fromdateString[3:5] + fromdateString[0:2]) #Convert into YYMMDD for BST
        todateString = str(self.toEdit.text())
        todate = int(todateString[6:8] + todateString[3:5] + todateString[0:2])

        dates, expiryperiods, types, positions, weights = functions.returnFromTo(fromdate, todate) #Return all objects between the two dates

        fromtoitems = []

        for i in range(len(dates)): #Append items to list to write to QTableWidget
            fromtoitems.append([dates[i], expiryperiods[i], types[i], positions[i], weights[i]])
            fromtoitems[i][0] = str(fromtoitems[i][0])
            fromtoitems[i][0] = fromtoitems[i][0][4:6] + "/" + fromtoitems[i][0][2:4] + "/" + fromtoitems[i][0][0:2] #Reconvert YYMMDD to DD/MM/YY

        self.tableWidget.setRowCount(len(fromtoitems)) #Format table
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date', 'Expiry Period', 'Type', 'Position', 'Weight'])

        for i, row in enumerate(fromtoitems): #Write to table
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

        self.tableConfirmLabel.setText(" " + str(fromdateString) + " to " + str(todateString)) #Set confirmation label

        self.showItemsOnMap() #Show items on map

    def sortDateItems(self):

        allitems = []
        for row in range(self.tableWidget.rowCount()): #Read from table. For some reason a nested for loop didn't work
            allitems.append([str(self.tableWidget.item(row, 0).text()), str(self.tableWidget.item(row, 1).text()),
                             str(self.tableWidget.item(row, 2).text()), str(self.tableWidget.item(row, 3).text()),
                             str(self.tableWidget.item(row, 4).text())])

        self.tableWidget.setRowCount(0) #Reset table

        self.tableWidget.setRowCount(len(allitems)) #Format table
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date', 'Expiry Period', 'Type', 'Position', 'Weight'])

        datesorted = sorted(allitems, key=lambda x: x[0]) #Sort nested list with regards to date

        for i, row in enumerate(datesorted): #Write to table
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

    def sortTypeItems(self):

        allitems = []
        for row in range(self.tableWidget.rowCount()): #Read from table. For some reason a nested for loop didn't work
            allitems.append([str(self.tableWidget.item(row, 0).text()), str(self.tableWidget.item(row, 1).text()),
                             str(self.tableWidget.item(row, 2).text()), str(self.tableWidget.item(row, 3).text()),
                             str(self.tableWidget.item(row, 4).text())])

        self.tableWidget.setRowCount(0) #Reset table

        self.tableWidget.setRowCount(len(allitems))
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date', 'Expiry Period', 'Type', 'Position', 'Weight'])

        typesorted = sorted(allitems, key=lambda x: x[2])

        for i, row in enumerate(typesorted):
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

    def sortWeightItems(self):

        allitems = []
        for row in range(self.tableWidget.rowCount()): #Read from table. For some reason a nested for loop didn't work
            allitems.append([str(self.tableWidget.item(row, 0).text()), str(self.tableWidget.item(row, 1).text()),
                             str(self.tableWidget.item(row, 2).text()), str(self.tableWidget.item(row, 3).text()),
                             str(self.tableWidget.item(row, 4).text())])

        self.tableWidget.setRowCount(0) #Reset table

        self.tableWidget.setRowCount(len(allitems))
        self.tableWidget.setColumnCount(5)
        self.tableWidget.setHorizontalHeaderLabels(['Arrival Date', 'Expiry Period', 'Type', 'Position', 'Weight'])

        weightsorted = sorted(allitems, key=lambda x: x[4])

        for i, row in enumerate(weightsorted):
            for j, col in enumerate(row):
                item = QTableWidgetItem(col)
                self.tableWidget.setItem(i, j, item)

    def showStatistics(self): #Opens statistics subwindow

        self.statisticsObject = statisticsWindow(self)
        self.statisticsObject.setFocus()
        self.statisticsObject.show()

class addOrDeleteWindow(QWidget, addOrDeleteWindow.Ui_Dialog):

    def __init__(self, parent=None):
        super(addOrDeleteWindow, self).__init__(parent)
        self.setupUi(self)

        self.connect(self.add, SIGNAL("clicked()"), self.addItem)
        self.connect(self.cancel, SIGNAL("clicked()"), self.closeWindow)
        self.connect(self.deleteFromTo, SIGNAL("clicked()"), self.deleteFromToItem)

    def addItem(self):
        date = str(self.arrivalEdit.text())
        expiry = str(self.expiryEdit.text())
        position = str(self.positionEdit.text())
        weight = str(self.weightEdit.text())
        type = str(self.typeEdit.text())

        functions.newitem(date, expiry, type, position, weight)

    def deleteFromToItem(self):

        fromdate = str(self.fromEdit.text())
        todate = str(self.toEdit.text())
        fromdate = int(fromdate[6:8] + fromdate[3:5] + fromdate[0:2])
        todate = int(todate[6:8] + todate[3:5] + todate[0:2])
        functions.deleteItems(fromdate, todate)

    def deleteTable(self):

        keys = []
        vals = []
        for row in range(form.tableWidget.rowCount()):  # Read from table. For some reason a nested for loop didn't work
            keys.append(str(form.tableWidget.item(row, 0).text()))
            vals.append([str(form.tableWidget.item(row, 2).text()), int(form.tableWidget.item(row, 4).text())]) #Only use Type and Weight for comparison

        functions.deleteSpecific(keys,vals)


    def closeWindow(self):
        self.close()

class statisticsWindow(QWidget, statisticsWindow.Ui_Dialog):

    def __init__(self, parent=None):
        super(statisticsWindow, self).__init__(parent)
        self.setupUi(self)
        self.connect(self.cancel, SIGNAL("clicked()"), self.closeWindow)

        expiryperiods = []
        weights = []

        for row in range(form.tableWidget.rowCount()):
            expiryperiods.append(int(form.tableWidget.item(row, 1).text()))
            weights.append(int(form.tableWidget.item(row, 4).text()))

        meanexpiryperiods = sum(expiryperiods)/len(expiryperiods)
        self.meanExpiryEdit.setText(str(meanexpiryperiods) + " Days")

        meanweights = sum(weights)/len(weights)
        self.meanWeightEdit.setText(str(meanweights) + " Gramms")

    def closeWindow(self):
        self.close()

app = QApplication(sys.argv)
form = MainWindow()
form.setFocus()
form.setStyleSheet("MainWindow {background: '#E7E4D3';}")
form.setWindowTitle("Supermarket Food Database")
form.show()
app.exec_()