# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'statistics.ui'
#
# Created: Tue Dec 13 10:46:54 2016
#      by: PyQt4 UI code generator 4.9.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(365, 177)
        Dialog.setAutoFillBackground(True)
        self.statsTitle = QtGui.QLabel(Dialog)
        self.statsTitle.setGeometry(QtCore.QRect(150, 30, 181, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Courier"))
        font.setPointSize(14)
        self.statsTitle.setFont(font)
        self.statsTitle.setObjectName(_fromUtf8("statsTitle"))
        self.cancel = QtGui.QPushButton(Dialog)
        self.cancel.setGeometry(QtCore.QRect(140, 130, 113, 32))
        self.cancel.setObjectName(_fromUtf8("cancel"))
        self.meanExpiryLabel = QtGui.QLabel(Dialog)
        self.meanExpiryLabel.setGeometry(QtCore.QRect(50, 70, 151, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Courier"))
        font.setPointSize(13)
        self.meanExpiryLabel.setFont(font)
        self.meanExpiryLabel.setObjectName(_fromUtf8("meanExpiryLabel"))
        self.meanWeightLabel = QtGui.QLabel(Dialog)
        self.meanWeightLabel.setGeometry(QtCore.QRect(50, 100, 131, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Courier"))
        font.setPointSize(13)
        self.meanWeightLabel.setFont(font)
        self.meanWeightLabel.setObjectName(_fromUtf8("meanWeightLabel"))
        self.meanExpiryEdit = QtGui.QLabel(Dialog)
        self.meanExpiryEdit.setGeometry(QtCore.QRect(210, 70, 141, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Courier"))
        font.setPointSize(13)
        self.meanExpiryEdit.setFont(font)
        self.meanExpiryEdit.setObjectName(_fromUtf8("meanExpiryEdit"))
        self.meanWeightEdit = QtGui.QLabel(Dialog)
        self.meanWeightEdit.setGeometry(QtCore.QRect(210, 100, 141, 16))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Courier"))
        font.setPointSize(13)
        self.meanWeightEdit.setFont(font)
        self.meanWeightEdit.setObjectName(_fromUtf8("meanWeightEdit"))

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Dialog", None, QtGui.QApplication.UnicodeUTF8))
        self.statsTitle.setText(QtGui.QApplication.translate("Dialog", "Statistics", None, QtGui.QApplication.UnicodeUTF8))
        self.cancel.setText(QtGui.QApplication.translate("Dialog", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.meanExpiryLabel.setText(QtGui.QApplication.translate("Dialog", "Mean expiry period:", None, QtGui.QApplication.UnicodeUTF8))
        self.meanWeightLabel.setText(QtGui.QApplication.translate("Dialog", "Mean weight:", None, QtGui.QApplication.UnicodeUTF8))
        self.meanExpiryEdit.setText(QtGui.QApplication.translate("Dialog", "-", None, QtGui.QApplication.UnicodeUTF8))
        self.meanWeightEdit.setText(QtGui.QApplication.translate("Dialog", "-", None, QtGui.QApplication.UnicodeUTF8))

