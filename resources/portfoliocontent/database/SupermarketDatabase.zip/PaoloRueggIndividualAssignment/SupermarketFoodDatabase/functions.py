### Imports

import binary_search_tree #The files you want to use
from food import Food #The individual classes you want to use in this file without going food.Food
import matplotlib.pyplot as plt
import matplotlib.patches as patches

### CREATE BST ###

date_bst = binary_search_tree.BinarySearchTree()

#FIND MIN

def find_min(node):
    # TODO
    while node.leftChild:
        node = node.leftChild
    return node

#FIND MAX

def find_max(node):

    while node.rightChild:
        node = node.rightChild
    return node

#OBSOLETE# INTERVAL
#Finds all keys in the BST between to keys

def interval(node, min_key, max_key):

    keys = []
    if min_key <= node.key <= max_key:
        if node.leftChild and node.key != min_key:
            keys += interval(node.leftChild, min_key, max_key)
        keys.append(node.key)
        if node.rightChild and node.key != max_key:
            keys += interval(node.rightChild, min_key, max_key)
    elif node.key < min_key:
        if node.rightChild:
            keys += interval(node.rightChild, min_key, max_key)
    else: # node.key > max_key
        if node.leftChild:
            keys += interval(node.leftChild, min_key, max_key)
    return keys

#INTERVALNODE
#Returns nodes instead of keys and thus saves computation time

def intervalnode(node, min_key, max_key):

    nodes = []
    if min_key <= node.key <= max_key:
        if node.leftChild and node.key != min_key:
            nodes += intervalnode(node.leftChild, min_key, max_key) #Recursion to find correct node
        nodes.append(node)
        if node.rightChild and node.key != max_key:
            nodes += intervalnode(node.rightChild, min_key, max_key)
    elif node.key < min_key:
        if node.rightChild:
            nodes += intervalnode(node.rightChild, min_key, max_key)
    else: # node.key > max_key
        if node.leftChild:
            nodes += intervalnode(node.leftChild, min_key, max_key)
    return nodes #Returns all the nodes between the two keys


#READ DATA FROM TXT FILE

def loadObjects(filename):

    file = open("InputOutput/"+filename, 'r')

    for i in range(4): #Read Header Info
        file.readline()
    while True:
        line = str(file.readline()) #Read the next line
        if len(line) < 5: #We know that we have reached the end of the line if this statement is true
            break
        values = line.split('|') #Split the line into the values
        date = values[0].strip() #Strip the values of whitespace and assign them to correct variable
        key = int(date[6:8] + date[3:5] + date[0:2])
        expiry = values[1].strip()
        type = values[4].strip()
        position = str(values[2]).strip()
        weight = values[3].strip()
        instance = Food(expiry,type,position,weight) #Create instance and put it into BST
        date_bst.put(key,instance)

    file.close()

#ADD A FOOD
#Adds a new food to the BST

def newitem(dateinput, expiryperiod, type, position, weight):

    try:
        key = int(str(dateinput[6:8]) + str(dateinput[3:5]) + str(dateinput[0:2])) #Converts DD/MM/YY to YYMMDD for BST
        instance = Food(expiryperiod, type, position, weight) #Create Food instance based on input
        date_bst.put(key, instance) #Add it to the BST
    except:
        print "There was an error, please try again!"

#newitem()

#BST RETURN OBJECTS
#Returns a list of Food objects between two dates

def returnObjects(fromdate, todate):

    objects = []
    keys = interval(date_bst.root, fromdate, todate)  #Returns a list of keys
    for key in keys:
        instance = date_bst.get(key)
        objects.append(instance)

    return keys, objects

#BST_RETURN [DATE, EXPIRY, TYPE, POSITION, WEIGHT]
#Returns five lists with the values of Food instances between to dates

def returnFromTo(fromdate, todate):

    dates = []
    expiryperiods = []
    types = []
    positions = []
    weights = []

    nodes = intervalnode(date_bst.root, fromdate, todate) #Returns a list of nodes!

    for node in nodes:
         for v in node.payload: #All the attributes of the Food instances
            dates.append(node.key) #Append the key of the node
            expiryperiods.append(v[0])
            types.append(v[1])
            positions.append(v[2])
            weights.append(v[3])

    return dates, expiryperiods, types, positions, weights

#DISPLAY FROM TO
#Obsolete function used before Qt interface was built

def displayFromTo():

    fromdate = str(raw_input("What date do you want to display entries from? (DD/MM/YY)  "))
    print "\n"
    todate = raw_input("What date do you want to display entries to? (DD/MM/YYYY)  ")
    print "\n"

    fromdate = int(fromdate[6:8] + fromdate[3:5] + fromdate[0:2])
    todate = int(todate[6:8] + todate[3:5] + todate[0:2])

    print "Arrival date", " ", "Expiry period", " ", "Position", " ", "Weight", " ", "Type", "\n"

    dates, expiryperiods, types, positions, weights = returnFromTo(fromdate, todate)

    for i in range(len(dates)):
        dates[i] = str(dates[i])
        dates[i] = dates[i][4:6] + "/" + dates[i][2:4] + "/" + dates[i][0:2]

    for d,e,p,t,w in zip(dates, expiryperiods, types, positions, weights):
        print d,"       ",e,"             ",p,"   ",w,"    ", t

#SAVE DATA TO TXT FILE

def saveObjects(filename, fromdate, todate):

    file = open("InputOutput/"+filename, 'w') #Write mode

    file.write("Food Inventory") #Below write statements ensure that loadObjects and saveObject have the same layout
    file.write("\n")             #This ensures that the user can overwrite files and update them
    file.write("\n")
    file.write("Arrival date  |  Expiry period  |  Position  |  Weight  |  Type")
    file.write("\n")
    file.write("              |                 |            |          |")
    file.write("\n")

    dates, expiryperiods, types, positions, weights = returnFromTo(fromdate, todate)

    for i in range(len(dates)):
        dates[i] = str(dates[i])
        line = str(dates[i][4:6]+"/"+dates[i][2:4]+"/"+dates[i][0:2]) + "      |  " + str(expiryperiods[i]) + "              |  " + str(positions[i]) + "     |  " + str(weights[i]) + "     |  " + str(types[i])
        file.write(line)
        file.write("\n") #Carriage return
    file.close()


#SHOW EXPIRED FOODS

def showExpired(todayinput):

    today = int(todayinput[6:8] + todayinput[3:5] + todayinput[0:2]) #Converts input to YYMMDD for BST access

    dates, expiryperiods, types, positions, weights = returnFromTo(today-90, today) #Looks at all perishable foods within the last three months

    expired = []

    for i in range(len(dates)):
        dates[i] = int(dates[i])
        expiryperiods[i] = int(expiryperiods[i])
        if dates[i] + expiryperiods[i] < today: #If the arrival date plus the expiry period are smaller than today, the food must be expired
            expired.append([dates[i], expiryperiods[i], types[i], positions[i], weights[i]])

    for i in range(len(expired)):
        expired[i][0] = str(expired[i][0])
        expired[i][0] = expired[i][0][4:6] + "/" + expired[i][0][2:4] + "/" + expired[i][0][0:2]

    return expired

#SHOW EXPIRING FOODS

def showExpiring(todayinput):

    today = int(todayinput[6:8] + todayinput[3:5] + todayinput[0:2])
    dates, expiryperiods, types, positions, weights = returnFromTo(today-90, today) #Looks at all perishable foods within the last three months

    expiring = []

    for i in range(len(dates)):
        dates[i] = int(dates[i])
        expiryperiods[i] = int(expiryperiods[i])
        if dates[i] + expiryperiods[i] == today: #If the arrival date plus the expiry period equal today, the food must expire on that day
            expiring.append([dates[i], expiryperiods[i], types[i], positions[i], weights[i]])

    for i in range(len(expiring)):
        expiring[i][0] = str(expiring[i][0])
        expiring[i][0] = expiring[i][0][4:6] + "/" + expiring[i][0][2:4] + "/" + expiring[i][0][0:2]

    return expiring

    #OBSOLETE COMMAND LINE OUTPUT
    # print "\n"
    # print "EXPIRING on ", todayinput, "\n"
    # print "Arrived on", " ", "Position", " ", "Weight", " ", "Type", "\n"
    # for i in range(len(expiring)):
    #     print expiring[i][0], "  ", expiring[i][1], "  ", expiring[i][3], "  ", expiring[i][2]

#DELETE FROM TO

def deleteItems(fromdate, todate):

    keys, objects = returnObjects(fromdate, todate) #Because we don't need much information we use the less complex
                                                    #returnObjects function to return the keys

    for key in keys:
        date_bst.delete(key)

#DELETE SPECIFIC OBJECT IN KEY
#Not completed

def deleteSpecific(keys, vals):

    print keys
    print vals
    for key in keys:
        try:
            key = int(key[6:8] + key[3:5] + key[0:2])
            node = binary_search_tree.BinarySearchTree._get(date_bst, key, date_bst.root)
            print node.payload
            for v in range(len(vals)):
                if any(vals[v][0] in s for s in node.payload):
                    print "DELETED"
                    thekey = node.payload.key(any(vals[v][0] in s for s in node.payload))
                    print thekey
                    del node.payload[thekey]
            print node.payload
        except:
            continue

#PLOT ITEMS
#Plots items on a matplotlib plot and saves it as a file

def plotItems(positions):

    xpositions = []
    ypositions = []

    for i in range(len(positions)):
        xpositions.append(int(positions[i][1])) #Positions were previously converted to strings, hence index 1 is x-coordinate
        ypositions.append(int(positions[i][3]))

    fig1 = plt.figure()
    ax1 = fig1.add_subplot(111, aspect='equal')
    ax1.set_ylim(-2, 7) #Format plot
    ax1.set_xlim(0, 7)
    plt.xlabel('Shelf')
    plt.ylabel('Distance along shelf (m)')
    ax1.text(3.2, -1.5, '       Checkout       ', style='italic',
             bbox={'facecolor': '#F78383', 'alpha': 0.5, 'pad': 2}) #Set custom text boxes
    ax1.text(1, -1.5, '  Entrance  ', style='italic',
             bbox={'facecolor': '#206BA4', 'alpha': 0.5, 'pad': 2})
    ax1.set_axis_bgcolor('#FFFFFF')
    #Draw rectangles to represent aisles
    for p in [
        patches.Rectangle(
            (1, 0), 1, 6,               #XY, width, height
            facecolor="#BBD9EE"
        ),
        patches.Rectangle(
            (3, 0), 1, 6,
            facecolor="#BBD9EE"
        ),
        patches.Rectangle(
            (5, 0), 1, 6,
            facecolor="#BBD9EE"
        ),

    ]:
        ax1.add_patch(p)
        ax1.scatter(xpositions,ypositions) #Use scatter diagram to plot all the foods into the diagram
    fig1.savefig('Map.png',facecolor='#E7E4D3', dpi=89, bbox_inches='tight') #Save the figure as Map.png