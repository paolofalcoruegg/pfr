class Food:
    def __init__(self, expiry=0, type ='', position=[0,0], weight=0):
        self.expiry = expiry
        self.type = type
        self.position = position
        self.weight = weight
        self.value = [self.expiry, self.type, self.position, self.weight]

    def __getitem__(self, index): #Function needed to access attributes via square brackets
        return self.value[index]

    def __str__(self):
        return "["+str(self.expiry)+", "+self.type+", "+str(self.position)+", "+str(self.weight)+"]"
